package compiler.parser;

public class ParseException extends Exception {
    public ParseException(String string) {
        super(string);
    }
}