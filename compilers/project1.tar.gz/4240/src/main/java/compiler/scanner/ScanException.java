package compiler.scanner;

public class ScanException extends Exception {
    public ScanException(String msg) {
        super(msg);
    }
}